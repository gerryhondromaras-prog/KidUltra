
# CHECKLIST ΠΡΙΝ ΤΟ RELEASE
- [ ] OCR end-to-end
- [ ] DXF generator με έλεγχο γεωμετρίας
- [ ] Guardian recovery policies
- [ ] EABP caps/metrics
- [ ] UI polish + i18n
- [ ] Installers (Win/macOS)
- [ ] Τεκμηρίωση/Manual χρήστη (PDF)
