
KID ULTRA – Python Edition (Demo)
=================================

Τι περιλαμβάνει
---------------
• Γραφικό περιβάλλον (Tkinter)
• Registry agents που εκτελούν εργασίες/προσομοιώσεις
• Guardian Loop (ανίχνευση αδράνειας ανά 30s + ώθηση)
• EABP (Exponential Agent Borrowing – διπλασιασμός agents ανά 10s, έως 512)
• Live πίνακας προόδου
• Stubs για OCR/DXF

Πως το τρέχω;
-------------
1) Κατέβασε και εγκατέστησε Python 3.11/3.12 (Windows x64) από python.org (Add to PATH).
2) Άνοιξε terminal στο φάκελο που αποσυμπίεσες.
3) Τρέξε:  python app.py

Μετατροπή σε .exe
-----------------
pip install pyinstaller
pyinstaller --onefile --noconsole app.py
Θα παραχθεί εκτελέσιμο στο φάκελο dist/

Σημειώσεις
----------
• Το πακέτο είναι demo: δείχνει πώς λειτουργούν Guardian/EABP/Agents με live προόδους.
• Τα modules OCR/DXF είναι placeholders για μελλοντική ενσωμάτωση.
