
# Κίνδυνοι & Περιορισμοί

- Email/Cloud upload δεν υποστηρίζονται από τον βοηθό (χειροκίνητη λύση από τον developer).
- iOS sideload/TestFlight απαιτεί Apple Developer.
- Πολύ επιθετικό EABP μπορεί να υπερφορτώσει σύστημα (χρήση caps).
