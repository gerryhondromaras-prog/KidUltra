
# Testing & QA (κλάδος 4)

- Unit tests για agents, guardian, eabp, progress store
- Fuzz testing σε OCR/DXF pipelines
- Regression suite για UI events
- Long-run soak tests (24h) για αδράνεια/ανάκαμψη
- Σενάρια σφαλμάτων και auto-fix policies
