
# Release & Deployment

## Windows
- PyInstaller onefile/onedir
- Code signing (EV certificate) – προαιρετικό
- MSI δημιουργία με WiX/NSIS

## macOS
- `py2app` ή `briefcase` / notarization

## iOS/Android
- Native wrappers (Kivy/Briefcase/Flutter-bridge) ή ξεχωριστή mobile app
- TestFlight/Play Console — απαιτεί Developer accounts

## Διανομή
- Ο βοηθός ΔΕΝ μπορεί να στείλει email/ανεβάσει σε cloud. Παραδίδουμε αρχεία τοπικά.
