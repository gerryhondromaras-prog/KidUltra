
# ROADMAP
- Phase A: Σταθεροποίηση demo (agents, guardian, eabp, UI) ✅
- Phase B: OCR + DXF παραγωγή (πραγματικές βιβλιοθήκες) ⬅ ΤΡΕΧΟΝ
- Phase C: Export/Installers για Windows/macOS
- Phase D: Mobile Management & live telemetry
- Phase E: Hardening, code signing, releases
