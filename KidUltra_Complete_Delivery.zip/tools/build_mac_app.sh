#!/usr/bin/env bash
# Build macOS app (example using py2app)
python3 -m pip install py2app
python3 setup.py py2app
