
# iOS TestFlight Σημειώσεις
- Απαιτεί Apple Developer (99$/έτος).
- Δημιουργία app id, provisioning profiles, certificates.
- Upload μέσω Xcode/Transporter (εκτός πλατφόρμας βοηθού).
