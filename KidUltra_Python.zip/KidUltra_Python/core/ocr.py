# -*- coding: utf-8 -*-
# Placeholder για Smart OCR (ενσωμάτωση με Tesseract/ PaddleOCR στο μέλλον)
def ocr_validate(image_path:str) -> dict:
    return {"ok": True, "text": "(demo) OCR not enabled in this minimal build."}
